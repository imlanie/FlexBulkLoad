﻿using System;
using System.IO;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.FileExtensions;
using Microsoft.Extensions.Configuration.Json;
using CsvHelper;  // CsvHelper C# Library from Josh Close


/* INSTRUCTIONS:
This programm [FlexBulkLoad] loads the contents .CSV file into a database table using bulkcopy.
Option variable name is Append (line 86) to choose to append the data to an existing table or create a new table  
 DB connection string, file name/path and target table name -- configs are stored in appsettings.json
*/

namespace FileLoader
{
    class Program
    {
        static int Main(string[] args)
        {

            if (args.Length == 0)
            {
                //System.Console.WriteLine("Please enter a numeric argument.");
                using(SqlConnection connection = new SqlConnection()) 
                using(SqlConnection connection2 = new SqlConnection()) 
            {
            
// Get the Source file name, target table name, database connection string
                var builder = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json");
           
                IConfiguration config = new ConfigurationBuilder()
                    .AddJsonFile("appsettings.json", true, true)
                    .Build();


// READ THE CONTENTS OF A CSV FILE TO A DATATABLE OBJECT

            string FilePath = $"{ config["FileName"] } ";

            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
                
            var sr = new StreamReader(FilePath);
            var csv = new CsvReader(sr);   
            
            string line = sr.ReadLine();
            string[] value = line.Split(",");
           
            DataTable dt = new DataTable();
            DataRow row;
            foreach (string datacol in value)
            {
                dt.Columns.Add(new DataColumn(datacol));
            }
                while (!sr.EndOfStream)
            {
           
            value = sr.ReadLine().Split(",");
              
            if (value.Length == dt.Columns.Count)
            {
                row = dt.NewRow();
                row.ItemArray = value;
                dt.Rows.Add(row);
                Console.WriteLine(dt.ToString());
            }
        }
    
            
// BEGIN NEW SECTION:  BUILD A DDL STATEMENT SQL STRING TO CREATE SQL SERVER STAGING TABLE 

            connection.ConnectionString = $"{ config["DBConn"] } ";
            connection.Open();

           var TgtTable = $"{ config["TgtTable"] } ";
           
          string CreateStgTbl = " Create Table " + TgtTable.ToString() + "(";
           
           /*  SET VARIABLE TO APPEND (true/false) THE FILE DATA TO AN EXISTING 
                TABLE OR CREATE A NEW TABLE */
           bool Append = false;

          Console.WriteLine("Append = " + Append.ToString());

           if (Append == true)

// THIS SECTION WILL BE SKIPPED IF APPEND DATA OPTION IS CHOSEN

        {

           { 
           CreateStgTbl = "Drop Table " + TgtTable.ToString() +  CreateStgTbl;
           }

              string[] field = line.Split(",");
              for (int i = 0; i < value.Length; i++)

              
         try
            {
                var fields = field[i];
                CreateStgTbl = CreateStgTbl + "[" + fields.ToString() + "]"
                + " nvarchar(255),";
                //Console.WriteLine(CreateStgTbl.ToString());
            } 

         catch (SqlException exFieldLoop)
         
            {
             Console.WriteLine("SQL Error: " + exFieldLoop.Message.ToString());
            }

            // Add Identity Key to the table
            string AppendIdentity = CreateStgTbl.ToString() + " TblRowID int identity(1,1)";
            
            // Create end right parenthesis
            string CreateStgTblFinal = AppendIdentity + ")" ;
            
            
            connection.Close();
            connection2.ConnectionString = $"{ config["DBConn"] } ";
            connection2.Open();
             
            //string CreateNewTable = $"{ config["CreateNewTable"] } ";

            SqlCommand cmd = new SqlCommand(CreateStgTblFinal, connection2);
            
            try
                {                
                    cmd.ExecuteNonQuery();
                }

            catch (SqlException exCrStageTbl)
          
                {
                   Console.WriteLine("Create Stage Table Error: " + exCrStageTbl.Message.ToString());
                }

            finally

                {connection2.Close();}
            }

// END NEW SECTION:  BUILD A DDL STATEMENT SQL STRING TO CREATE THE STAGING TABLE 

    
// BEGIN NEW SECTION:  USING SQL SERVER BULKCOPY COMMAND LOAD THE STAGING TABLE
          
            var sqlBulk = new SqlBulkCopy(connection.ConnectionString);
            sqlBulk.DestinationTableName = TgtTable;
           
            sqlBulk.BatchSize = dt.Rows.Count;
            try
                {
                    sqlBulk.WriteToServer(dt);
                    string varMsg = " rows have been loaded from " + FilePath + " to table " + TgtTable + '.';
                    Console.WriteLine(sqlBulk.BatchSize.ToString() + varMsg.ToString());
                }
 
            catch (Exception exBulkCopy)
                {
                    Console.WriteLine("BulkCopy Error:  " + exBulkCopy.Message);
                }
 
            finally
                {
                    sqlBulk.Close();
                    stopWatch.Stop();
                    // Get the elapsed time as a TimeSpan value.
                    TimeSpan ts = stopWatch.Elapsed;

                    // Format and display the TimeSpan value.
                    string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                    ts.Hours, ts.Minutes, ts.Seconds,
                    ts.Milliseconds / 10);
                    Console.WriteLine("RunTime " + elapsedTime);
                }
            }
        }

        return 1;
        }
   }
}

// END SECTION:  Load the DB table using BulkCopy command

   
        // var guid = Guid.NewGuid().ToString();
        // Console.WriteLine(guid.ToString());



                /* this isn't working when assigned from the appsettings.json
                try {

                    switch (CrtNwTbl)
                        { 
                            case "Yes":
                            {cmd.ExecuteNonQuery();}
                            //Console.WriteLine(CrtNwTbl + " Drop and recreate staging table".ToString());
                            break;
                            case "No":
                            Console.WriteLine(CrtNwTbl + " Keep existing staging table. Contents of the file appended.".ToString());
                            break;
    
                            default:
                            Console.WriteLine(CrtNwTbl + " Unknown value");
                            break;
                        }                    

                    }
    
                catch (SqlException exCreatingTbl)
                    {
                     Console.WriteLine("SQL Error" + exCreatingTbl.Message.ToString());
                     //return 0;
                     } 
                      line = line.Replace(@"""", "");
                     
                     */


          
    